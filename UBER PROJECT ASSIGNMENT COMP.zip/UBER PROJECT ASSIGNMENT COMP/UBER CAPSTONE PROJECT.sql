                         --UBER CAPSTONE PROJECT--

SELECT * FROM [dbo].[rides_dataset1$]
SELECT * FROM [dbo].[city_dataset2$]
SELECT * FROM [dbo].[driver_dataset3$]
SELECT * FROM [dbo].['payment_dataset 4$']

 
--
--HOW CAN YOU QUICKLY ACCESS INFORMATION ON AVERAGE FARES FOR EACH CITY?
SELECT 
    start_city,             
    AVG(fare) AS average_fare

FROM rides_dataset1$

WHERE fare IS NOT NULL
GROUP BY start_city
ORDER BY average_fare DESC;

--HOW CAN QUERY PERFORMANCE BE IMPROVED WHEN FILTERING RIDES BY DATE?
CREATE INDEX idx_ride_date ON rides_dataset1$(ride_date);

SELECT *
FROM rides_dataset1$
WHERE ride_date >= '2024-05-01' AND ride_date < '2024-05-02';


SELECT ride_id, fare FROM rides_dataset1$ WHERE ride_date = '2024-05-01';

UPDATE STATISTICS rides_dataset1$;
ALTER INDEX ALL ON rides_dataset1$ REBUILD;

--WHAT IS THE AVERAGE RIDE DURATION FOR EACH CITY? HOW DOES THIS RELATE TO CUSTOMER SATISFACTION?
SELECT 
    start_city,
    AVG(DATEDIFF(MINUTE, start_time, end_time)) AS avg_ride_duration,
    AVG(rating) AS avg_customer_rating        --used for condition customer satisfaction

FROM rides_dataset1$

WHERE start_time IS NOT NULL AND end_time IS NOT NULL AND rating IS NOT NULL

GROUP BY start_city
ORDER BY avg_ride_duration DESC;

--HOW FARE AMOUNTS VARY ACROSS DIFFERENT SEASONS? IDENTIFY ANY SIGNIFICANT TRENDS OR ANOMALIES IN FARE DISTRIBUTIONS.

SELECT
    CASE 
        WHEN MONTH(ride_date) IN (12, 1, 2) THEN 'Winter'   --HERE 1 TO 12 DENOTE ALL MONTHS IN A YEAR--
        WHEN MONTH(ride_date) IN (3, 4, 5) THEN 'Spring'
        WHEN MONTH(ride_date) IN (6, 7, 8) THEN 'Summer'
        WHEN MONTH(ride_date) IN (9, 10, 11) THEN 'Autumn'
        ELSE 'Unknown'
    END AS Season,
    
    COUNT(*) AS Total_Rides,
   
   AVG(fare) AS Avg_Fare,
    MIN(fare) AS Min_Fare,
    MAX(fare) AS Max_Fare,
    STDEV(fare) AS Fare_StdDev

FROM rides_dataset1$

WHERE fare IS NOT NULL AND ride_date IS NOT NULL

GROUP BY 
    CASE 
        WHEN MONTH(ride_date) IN (12, 1, 2) THEN 'Winter'
        WHEN MONTH(ride_date) IN (3, 4, 5) THEN 'Spring'
        WHEN MONTH(ride_date) IN (6, 7, 8) THEN 'Summer'
        WHEN MONTH(ride_date) IN (9, 10, 11) THEN 'Autumn'
        ELSE 'Unknown'
    END

ORDER BY Avg_Fare DESC;

--ANALYZE THE CANCELLATION PATTERNS BASED ON DIFFERENT TIMES OF DAY. WHICH HOURS HAVE THE HIGHEST 
--CANCELLATION RATES, AND WHAT IS THEIR IMPACT ON REVENUE?
SELECT 
    DATEPART(HOUR, start_time) AS RideHour,
    COUNT(*) AS TotalRides,
    SUM(CASE WHEN ride_status = 'Canceled' THEN 1 ELSE 0 END) AS CanceledRides,
    SUM(CASE WHEN ride_status = 'Completed' THEN fare ELSE 0 END) AS Revenue,
    
 CAST(SUM(CASE WHEN ride_status = 'Canceled' THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS DECIMAL(5,2)) AS CancellationRate

FROM rides_dataset1$

WHERE start_time IS NOT NULL

GROUP BY DATEPART(HOUR, start_time)

ORDER BY CancellationRate DESC;

--WHAT ARE THE CANCELLATION PATTERNS ACROSS CITIES? HOW DO THESE PATTERNS 
--CORRELATE WITH REVENUE FROM COMPLETED RIDES?
SELECT 
    start_city,
    COUNT(*) AS total_rides,
    
    SUM(CASE WHEN ride_status = 'Canceled' THEN 1 ELSE 0 END) AS canceled_rides,
    SUM(CASE WHEN ride_status = 'Completed' THEN fare ELSE 0 END) AS total_revenue,
    
 CAST(SUM(CASE WHEN ride_status = 'Canceled' THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS DECIMAL(5,2)) AS cancellation_rate

FROM rides_dataset1$

WHERE ride_status IN ('Completed', 'Canceled')

GROUP BY start_city
ORDER BY cancellation_rate DESC;

--HOW CAN YOU TRACK CHANGES IN RIDE STATUS FOR AUDITING PURPOSES?

--TO TRACK CHANGES IN RIDE STATUS FOR AUDITING PURPOSES, YOU NEED TO IMPLEMENT DATA CHANGE TRACKING MECHANISMS � 
--ESPECIALLY FOR FIELDS LIKE RIDE_STATUS

CREATE TABLE ride_status_audit (
    audit_id INT IDENTITY(1,1) PRIMARY KEY,
    ride_id INT,
    old_status VARCHAR(50),
    new_status VARCHAR(50),
    changed_at DATETIME DEFAULT GETDATE(),
    changed_by VARCHAR(100)
);

CREATE TRIGGER trg_ride_status_change
ON rides_dataset1$
AFTER UPDATE
AS
BEGIN
    INSERT INTO ride_status_audit (ride_id, old_status, new_status, changed_by)
    SELECT 
        d.ride_id,
        d.ride_status AS old_status,
        i.ride_status AS new_status,
        SYSTEM_USER
    FROM deleted d
    JOIN inserted i ON d.ride_id = i.ride_id
    WHERE d.ride_status <> i.ride_status;
END;

--WHAT PERFORMANCE METRICS CAN BE SUMMARIZED TO ASSESS DRIVER EFFICIENCY?
SELECT 
    d.driver_id,
    COUNT(r.ride_id) AS total_rides,
    AVG(r.rating) AS avg_rating,
    SUM(r.fare) AS total_revenue,
    SUM(CASE WHEN r.ride_status = 'Canceled' THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS cancellation_rate,
    AVG(DATEDIFF(MINUTE, r.start_time, r.end_time)) AS avg_ride_duration
FROM rides_dataset1$ r
JOIN driver_dataset3$ d ON r.driver_id = d.driver_id
WHERE r.ride_status = 'Completed'
GROUP BY d.driver_id
ORDER BY total_revenue DESC;

